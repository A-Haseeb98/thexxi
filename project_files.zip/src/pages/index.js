export { default as Home } from './Home';
export { default as Gallery } from './Gallery';
export { default as Roadmap } from './Roadmap';
export { default as FAQ } from './Faq';
export { default as About } from './About';
export { default as Team } from './Team';
export { default as Artist } from './Artist';
